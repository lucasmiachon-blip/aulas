# ⚡ RODE NO POWERSHELL - Ultra Rápido

## 🪟 VOCÊ ESTÁ NO WINDOWS? SEM PROBLEMA!

---

## 🚀 RODE AGORA (1 COMANDO):

### **No PowerShell, digite:**

```powershell
python corrigir_webhook.py
```

**É SÓ ISSO!** ✅

---

## 🧪 DEPOIS, TESTE:

```powershell
python testar_webhook.py
```

**OU abra no navegador:**

```
http://163.176.141.76:5678/webhook/chat?pergunta=Teste
```

---

## ✅ RESULTADO:

**Antes (ruim):** ❌
```json
{"model":"claude...","text":"Olá"}
```

**Depois (bom):** ✅
```
Olá! Como posso ajudá-lo?
```

---

## 🐍 NÃO TEM PYTHON?

### **Instale rápido:**

**Microsoft Store:**
1. Abra Microsoft Store
2. Procure "Python"
3. Instale

**OU Site oficial:**
https://www.python.org/downloads/

---

## 📋 TODOS OS COMANDOS:

```powershell
# 1. Corrigir webhook
python corrigir_webhook.py

# 2. Testar
python testar_webhook.py

# 3. (Se precisar) Criar workflow do zero
python setup_claude_webhook.py
```

---

## ⚡ ALTERNATIVA - PowerShell Puro

**Se preferir usar PowerShell em vez de Python:**

### **1. Permitir scripts (primeira vez):**

```powershell
Set-ExecutionPolicy RemoteSigned -Scope CurrentUser
```

### **2. Rodar:**

```powershell
.\corrigir_webhook.ps1
.\testar_webhook.ps1
```

---

## 🎯 RESUMO

| **O QUE** | **COMANDO** |
|-----------|-------------|
| Corrigir | `python corrigir_webhook.py` |
| Testar | `python testar_webhook.py` |
| Navegador | Abrir URL no Chrome/Edge |

---

## 💪 HANDS OFF CONFIRMADO NO WINDOWS!

**ZERO cliques no n8n!** 🙌

---

**RODE AGORA:**

```powershell
python corrigir_webhook.py
```

**Me diga o resultado!** 🚀
